from django.db import models

from core.uploads import upload_produtos
from core.validators import validate_image_upload


class TipoVestuario(models.TextChoices):
    HUMANO = 'humano', 'Para pessoas'
    PET = 'pet', 'Para pets'


class Produto(models.Model):
    """
    Modelo para armazenar produtos de vestuário.
    Pode ser vestuário humano ou para pets.
    """
    nome = models.CharField(max_length=200)
    
    descricao = models.TextField(
        blank=True,
        null=True,
        help_text="Descrição detalhada do produto"
    )
    
    tipo = models.CharField(
        max_length=10,
        choices=TipoVestuario.choices,
        help_text="Tipo de vestuário"
    )
    
    preco = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        help_text="Preço do produto"
    )
    
    foto = models.ImageField(
        upload_to=upload_produtos,
        blank=True,
        null=True,
        help_text="Foto do produto",
        validators=[validate_image_upload],
    )
    
    estoque = models.IntegerField(
        default=0,
        help_text="Quantidade em estoque"
    )
    
    ativo = models.BooleanField(
        default=True,
        help_text="Define se o produto está disponível para venda"
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = "Produto"
        verbose_name_plural = "Produtos"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.nome} ({self.get_tipo_display()})"


class ProdutoImagem(models.Model):
    produto = models.ForeignKey(
        Produto,
        related_name="imagens",
        on_delete=models.CASCADE,
    )
    imagem = models.ImageField(
        upload_to=upload_produtos,
        validators=[validate_image_upload],
    )
    ordem = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["ordem", "id"]
        verbose_name = "Foto do produto"
        verbose_name_plural = "Fotos dos produtos"

    def __str__(self):
        return f"Foto de {self.produto.nome}"
